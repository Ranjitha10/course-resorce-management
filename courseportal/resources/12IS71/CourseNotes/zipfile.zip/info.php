<?php
phpinfo();
?>
