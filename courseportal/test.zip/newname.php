<!DOCTYPE HTML> 
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body> 


<?php


$flag=0;
$nameErr = $usnErr = $semErr = $passErr =null;
$name = $usn = $sem = $pass =null ;

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
   
  $name = $_POST["name"]; 
  //test_input($_POST["name"]);
  $usn = $_POST["usn"];     //test_input($_POST["usn"]);
  $sem = $_POST["sem"];
  $pass = $_POST["pass"];
	// check if name only contains letters and whitespace
  if(!empty($_POST["name"])){
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) 
    {
		$flag=1;
      $nameErr = "Only letters and white space allowed"; 
    }
  }
  else
  {
    $nameErr = "Please enter this field";
	$flag=1;
  }
  
  if(!empty($_POST["usn"])){
    if (!preg_match("/^[a-z0-9A-Z]*$/",$usn)) 
    {
      $usnErr = "Only letters and digit allowed"; 
	  //echo "$usnErr";
	  $flag=1;
    }
  }
  else
  {
    $usnErr = "Please enter usn";
	$flag=1;
  } 
  
   if(!empty($_POST["pass"])){
    if (!preg_match("/^[a-z0-9A-Z]*$/",$usn)) 
    {
      $passErr = "Only letters and digit allowed"; 
	  $flag=1;
    }
  }
  else
  {
    $passErr = "Please enter password";
	$flag=1;
  } 
  
  if(!empty($_POST["sem"])){
    if (!preg_match("/^[1-8]$/",$sem)) 
    {
      $semErr = "Only digit"; 
	  $flag=1;
	  
    }
  }
  else
  {
    $semErr = "Please enter semester";
	$flag=1;
  } 
  
  if($flag==0){
 
 
 $servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password,"courseportal")  ;

if($conn)
 	{
	    // mysql inserting a new row
	    //$result = mysql_query("INSERT INTO student(USN,FName,Mname,Lname,Phno,emailid) VALUES('$usn',$Fname', '$Mname','Lname','phno', '$email')");
	 	//$sql="insert into student(USN,FName,Mname,Lname,Phno,emailid) values('".$_POST['usn']."','".$_POST['fname']."','".$_POST['mname']."','".$_POST['lname']."','".$_POST['ph']."','".$_POST['email']."')";
    	$sql = "insert into student(usn,name,sem,password) values('".$usn."','".$name."','".$sem."','".$pass."')";
    	if ($conn->query($sql) === TRUE) {
			echo "New record created successfully<br>";
			echo "<form action=new.php><input type=Submit value=HOME name=sub></form>";
			
			
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}
  }
    
}



// function test_input($data) {
//    $data = trim($data);
//    $data = stripslashes($data);
//    $data = htmlspecialchars($data);
//    return $data;
// }

//?>

<p><span class="error">* required field.</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
	<fieldset>
	<legend>Student registration:</legend>
		Name:<br>
		<input type="text" name="name" value="<?php echo $name;?>">
		<span class="error">* <?php echo $nameErr;?></span>
		<br><br>   
		USN:<br>
		<input type="text" name="usn" value="<?php echo $usn;?>">
		<span class="error">* <?php echo $usnErr;?></span>
		<br><br>
		Semester:<br>
		<input type="text" name="sem" value="<?php echo $sem;?>">
		<span class="error">* <?php echo $semErr;?></span>
		<br><br>
		Password:<br>
		<input type="password" name="pass" value="<?php echo $pass;?>">
		<span class="error">* <?php  echo $passErr;?></span>
		<br><br>
		<input type="submit" name="submit" value="Submit"><br> <br>
	</fieldset>
</form>
</body>
</html>